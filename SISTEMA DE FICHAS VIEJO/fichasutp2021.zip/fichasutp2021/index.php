<?php
include("conexion.php");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <script data-ad-client="ca-pub-9243779089772466" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <style>
.btn {
  border: none;
  color: white;
  padding: 14px 28px;
  font-size: 16px;
  cursor: pointer;
  
}
  .boton_1{
    text-decoration: none;
    padding: 3px;
    padding-left: 20px;
    padding-right: 20px;
    font-family: helvetica;
    font-weight: 300;
    font-size: 25px;
    font-style: italic;
    color: #fff;
    background-color: #82b085;
    border-radius: 15px;
    border: 3px double #006505;
  }
  .boton_1:hover{
    opacity: 0.6;
    text-decoration: none;
  }


.success {background-color: #4CAF50;} /* Green */
.success:hover {background-color: #46a049;}

       

.info {background-color: #2196F3;} /* Blue */
.info:hover {background: #0b7dda;}

.warning {background-color: #ff9800;} /* Orange */
.warning:hover {background: #e68a00;}

.danger {background-color: #f44336;} /* Red */
.danger:hover {background: #da190b;}

.default {background-color: #e7e7e7; color: black;} /* Gray */
.default:hover {background: #ddd;}
</style>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Datos de aspirantes</title>

	<!-- Bootstrap -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style_nav.css" rel="stylesheet">

	<style>
		.content {
			margin-top: 80px;
		}
	</style>

</head>
<body>
	<nav class="navbar navbar-default navbar-fixed-top">
		<?php include('nav.php');?>
	</nav>





	<div class="container">
	<div class="row">
	<div class="col-md-12">

<FONT SIZE=4>
<p>
<br><br><br>
<h2> <p style="text-align:center;"><FONT SIZE=7 style="color:#dab41a">TRÁMITE DE FICHAS PARA EL CUATRIMESTRE SEP-DIC 2021</FONT></p></p></h2>
<br>
<br>


  <b><FONT SIZE=6 style="color:#dab41a">PASO 1.-OPCIONES DE PAGO DE TU FICHA (MONTO DE $450)</FONT></b>
<br>
      <br>
      <u>OPCIÓN 1.-     EN CAJA DE LA UNIVERSIDAD:</u> <br><br>
        • ACUDIR DE LUNES A VIERNES EN HORARIO DE 9:00 A 15:00 HRS. (ATENDIENDO TODAS LAS MEDIDAS DEL SECTOR SALUD) <br>
        (EL ÁREA DE CAJA SE ENCUENTRA EN EL EDIFICIO “A”)<br><br>
	    
	    
	    <u>OPCIÓN 2.- EN CUALQUIER BANCO (TRANSFERENCIA, VENTANILLA O PRACTICAJA):</u><br>
		<br>
		REFERENCIAS BANCARIAS:</u><br>
		<br>
		 • 	BANCO BBVA BANCOMER<br>
		 • 	CUENTA BANCARIA: 0189393331<br>
		 • 	CUENTA CLABE: 0121500018933315<br>
		 • 	EN CONCEPTO INDICA NOMBRE Y APELLIDO<br><br>
			<h2 style="color:#FF0000";> CONSERVA TU COMPROBANTE</h2></p><br>


      <br><br>

  <b><FONT SIZE=6 style="color:#dab41a">PASO 2.-SI YA REALIZASTE TU PAGO REGÍSTRATE EN EL SIGUIENTE BOTÓN.</FONT></b>
<br><br>
   <div align='center'>
   <a class="boton_1" type="submit" href="pre.php" target = "blank">REGISTRO DE PAGO</a><br><br>
</div>
<br><br>
<div align='center'>
      <b><FONT SIZE=6 style="color:#dab41a">Tienes dudas:</FONT></b>
<br><b>
  Comunícate a Servicios Escolares<br>
  627 118 64 00 ext. 211  de lunes a viernes de 9:00  a 15:00 HRS<br>
  Correo: escolares@utparral.edu.mx</b><br>
<div>
</font>

<br><br><br>
</body>
</html>
